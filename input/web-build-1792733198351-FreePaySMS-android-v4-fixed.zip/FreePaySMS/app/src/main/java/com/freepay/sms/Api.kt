package com.freepay.sms

import org.json.JSONObject
import java.net.ConnectException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException
import java.net.UnknownServiceException
import javax.net.ssl.SSLException

data class ApiResult(val code: Int, val body: String, val error: String?, val ms: Long, val url: String) {
    val html: Boolean get() = body.trimStart().startsWith("<") && body.contains("html", true)
    val ok: Boolean get() = error == null && code in 200..299 && !html
}

data class Verdict(val ok: Boolean, val title: String, val msg: String)

object Api {
    private const val UA = "Mozilla/5.0 (Linux; Android) FreePaySMS/4.0 CHAKRABORTY-IT-LTD"

    /** Fixes common URL mistakes: missing scheme, trailing slash, /api or /api/ping.php pasted by user. */
    fun normalizeBase(raw: String): String {
        var s = raw.trim().replace(" ", "")
        if (s.isEmpty()) return ""
        if (!s.startsWith("http://", true) && !s.startsWith("https://", true)) s = "https://$s"
        s = s.trimEnd('/')
        for (suf in listOf("/api/ping.php", "/api/sms.php", "/api")) {
            if (s.endsWith(suf, true)) { s = s.dropLast(suf.length); break }
        }
        return s.trimEnd('/')
    }

    private fun host(u: String): String = try { URL(u).host.lowercase().removePrefix("www.") } catch (e: Exception) { "" }

    fun post(base: String, key: String, path: String, json: JSONObject, quick: Boolean = false): ApiResult {
        val t0 = System.currentTimeMillis()
        if (base.isEmpty()) return ApiResult(-1, "", "Server URL ফাঁকা", 0, "")
        var target = "$base/api/$path"
        val origHost = host(target)
        val maxHop = if (quick) 0 else 5   // quick = SMS আসার সাথে সাথে পাঠানোর দ্রুত চেষ্টা
        for (hop in 0..maxHop) {
            var c: HttpURLConnection? = null
            try {
                c = URL(target).openConnection() as HttpURLConnection
                c.instanceFollowRedirects = false
                c.requestMethod = "POST"
                c.connectTimeout = if (quick) 3000 else 15000
                c.readTimeout = if (quick) 4000 else 20000
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.setRequestProperty("Accept", "application/json")
                c.setRequestProperty("User-Agent", UA)
                c.setRequestProperty("X-Device-Key", key.trim())
                val payload = json.toString().toByteArray(Charsets.UTF_8)
                c.setFixedLengthStreamingMode(payload.size)
                c.outputStream.use { it.write(payload) }
                val code = c.responseCode
                if (code == 301 || code == 302 || code == 303 || code == 307 || code == 308) {
                    val loc = c.getHeaderField("Location")
                    if (!loc.isNullOrEmpty() && hop < maxHop) {
                        val next = URL(URL(target), loc).toString()
                        if (host(next) == origHost) { target = next; continue }   // same host only (key safety)
                    }
                }
                val stream = if (code >= 400) c.errorStream else c.inputStream
                val body = try { stream?.bufferedReader()?.use { it.readText() } ?: "" } catch (e: Exception) { "" }
                return ApiResult(code, body.take(600), null, System.currentTimeMillis() - t0, target)
            } catch (e: Exception) {
                return ApiResult(-1, "", describe(e), System.currentTimeMillis() - t0, target)
            } finally {
                try { c?.disconnect() } catch (e: Exception) { }
            }
        }
        return ApiResult(-1, "", "অনেকবার redirect হয়েছে", System.currentTimeMillis() - t0, target)
    }

    private fun describe(e: Exception): String = when (e) {
        is UnknownHostException -> "Domain খুঁজে পাওয়া যায়নি — URL এর বানান ঠিক আছে? ফোনে ইন্টারনেট চালু?"
        is SocketTimeoutException -> "সার্ভার সাড়া দিচ্ছে না (timeout) — সার্ভার চালু আছে কিনা দেখুন"
        is ConnectException -> "সার্ভারে কানেক্ট হয়নি — URL/port ভুল অথবা সার্ভার বন্ধ"
        is SSLException -> "SSL/HTTPS সমস্যা — সার্টিফিকেট ঠিক নেই। http:// দিয়ে চেষ্টা করুন অথবা SSL ঠিক করুন (${e.message ?: ""})"
        is UnknownServiceException -> "এই URL এ সরাসরি http চলছে না: ${e.message ?: ""}"
        else -> "${e.javaClass.simpleName}: ${e.message ?: ""}"
    }

    fun verdict(r: ApiResult): Verdict {
        val err = r.error
        return when {
            err != null -> Verdict(false, "Connection ব্যর্থ", err)
            r.ok -> Verdict(true, "Connected!", "সার্ভার সাড়া দিয়েছে (HTTP ${r.code}, ${r.ms} ms)")
            r.code in 200..299 && r.html -> Verdict(false, "API এর বদলে ওয়েব পেজ এসেছে",
                "হোস্টের anti-bot/security প্রটেকশন (যেমন InfinityFree/Cloudflare) অথবা ভুল URL path। URL এ /freepay ফোল্ডার ঠিক আছে কিনা দেখুন।")
            r.code == 401 || r.code == 403 -> Verdict(false, "অনুমতি নেই (HTTP ${r.code})",
                "Device key ভুল, অথবা সার্ভার/Cloudflare এই অ্যাপের রিকোয়েস্ট ব্লক করছে। config.php এর device_key মিলিয়ে নিন।")
            r.code == 404 -> Verdict(false, "ping.php পাওয়া যায়নি (HTTP 404)",
                "URL এর path ভুল। সঠিক হলে এই ঠিকানা ব্রাউজারে খুলবে: ${r.url}")
            r.code == 405 -> Verdict(false, "Method not allowed (HTTP 405)", "সার্ভার POST নিচ্ছে না — .htaccess/hosting rule দেখুন।")
            r.code == 429 -> Verdict(false, "অনেক বেশি রিকোয়েস্ট (HTTP 429)", "কিছুক্ষণ পর আবার চেষ্টা করুন।")
            r.code >= 500 -> Verdict(false, "সার্ভার এরর (HTTP ${r.code})", "সার্ভারের PHP error log দেখুন। ${r.body.take(120)}")
            else -> Verdict(false, "ব্যর্থ (HTTP ${r.code})", r.body.take(160))
        }
    }

    fun short(r: ApiResult): String = verdict(r).let { "${it.title}: ${it.msg}".take(200) }
}
