package com.freepay.sms.ui

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** Expanding radar rings + two orbiting dots + soft glow, drawn behind the logo. */
class PulseRingsView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG)
    private var glowShader: RadialGradient? = null
    private var t = 0f
    private var last = 0L
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 3600; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener {
            t = it.animatedValue as Float
            val now = SystemClock.uptimeMillis()
            if (now - last >= 33) { last = now; invalidate() }
        }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        val r = min(w, h) / 2f
        glowShader = RadialGradient(0f, 0f, r * 0.8f,
            intArrayOf(Color.argb(110, 124, 77, 255), Color.argb(0, 124, 77, 255)), null, Shader.TileMode.CLAMP)
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f; val cy = height / 2f
        val maxR = min(width, height) / 2f
        val d = resources.displayMetrics.density
        canvas.save(); canvas.translate(cx, cy); glow.shader = glowShader
        canvas.drawCircle(0f, 0f, maxR * 0.8f, glow); canvas.restore()
        for (i in 0..2) {
            val p = (t + i / 3f) % 1f
            ring.color = Color.argb(((1f - p) * 150).toInt().coerceIn(0, 255), 0, 229, 255)
            ring.strokeWidth = d * (1f + 2f * (1f - p))
            canvas.drawCircle(cx, cy, maxR * (0.28f + 0.72f * p), ring)
        }
        val orbit = 62f * d
        for (k in 0..1) {
            val a = 2 * PI * t + k * PI
            dot.color = if (k == 0) Color.rgb(0, 229, 255) else Color.rgb(179, 136, 255)
            canvas.drawCircle(cx + orbit * cos(a).toFloat(), cy + orbit * sin(a).toFloat(), 3.5f * d, dot)
        }
    }

    fun sync() { if (isAttachedToWindow) { Fx.syncAnim(anim, Fx.animOk(context)); invalidate() } }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); Fx.syncAnim(anim, Fx.animOk(context)) }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }
    override fun onWindowVisibilityChanged(v: Int) {
        super.onWindowVisibilityChanged(v)
        if (v == VISIBLE) Fx.syncAnim(anim, Fx.animOk(context)) else if (anim.isRunning) anim.pause()
    }
}
