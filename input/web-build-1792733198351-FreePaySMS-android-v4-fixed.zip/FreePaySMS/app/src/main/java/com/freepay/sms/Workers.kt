package com.freepay.sms

import android.content.Context
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import org.json.JSONObject
import java.util.Calendar
import java.util.concurrent.TimeUnit

object Uploader {
    fun payload(e: Store.Entry): JSONObject {
        val j = JSONObject().put("sender", e.sender).put("body", e.body)
        if (e.sim > 0) j.put("sim", e.sim)
        return j
    }

    /** প্রাইমারি সার্ভার ব্যর্থ হলে (আর ব্যাকআপ সার্ভার দেওয়া থাকলে) ব্যাকআপে চেষ্টা। quick মোডে শুধু প্রাইমারি। */
    fun send(c: Context, path: String, json: JSONObject, quick: Boolean): ApiResult {
        val r1 = Api.post(Store.url(c), Store.key(c), path, json, quick)
        if (r1.ok || quick) return r1
        val u2 = Store.url2(c)
        if (u2.isEmpty()) return r1
        val k2 = Store.key2(c).ifEmpty { Store.key(c) }
        val r2 = Api.post(u2, k2, path, json, false)
        return if (r2.ok) r2 else r1
    }

    /** SMS আসার সাথে সাথে সরাসরি পাঠানোর চেষ্টা (WorkManager জব ছাড়া → ব্যাটারি কম, দ্রুত)। */
    fun tryNow(c: Context, id: Long): Boolean {
        val e = Store.find(c, id) ?: return true
        if (e.status == "sent") return true
        val r = send(c, "sms.php", payload(e), true)
        if (r.ok) { Store.markSent(c, id); Store.setConn(c, true, "OK"); return true }
        return false
    }

    /** ব্যর্থ হলে WorkManager এ (একই id দুইবার জমা হয় না)। */
    fun enqueue(c: Context, id: Long) {
        val req = OneTimeWorkRequestBuilder<UploadWorker>()
            .setInputData(workDataOf("id" to id))
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS).build()
        WorkManager.getInstance(c).enqueueUniqueWork("up-$id", ExistingWorkPolicy.KEEP, req)
    }
}

object Sched {
    /** ব্যাটারি সাশ্রয়: ৬০ মিনিটে একবার, শুধু নেটওয়ার্ক আছে ও ব্যাটারি কম নয় এমন সময় */
    fun ping(c: Context) {
        val cons = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).setRequiresBatteryNotLow(true).build()
        WorkManager.getInstance(c).enqueueUniquePeriodicWork("ping", ExistingPeriodicWorkPolicy.UPDATE,
            PeriodicWorkRequestBuilder<PingWorker>(60, TimeUnit.MINUTES).setConstraints(cons).build())
    }

    /** রোজ রাত ৯টায় একবার (দিনে ১টি জব — ব্যাটারিতে প্রায় কিছুই লাগে না) */
    fun summary(c: Context, on: Boolean) {
        val wm = WorkManager.getInstance(c)
        if (!on) { wm.cancelUniqueWork("summary"); return }
        val now = Calendar.getInstance()
        val t = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 21); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
        if (t.timeInMillis <= now.timeInMillis) t.add(Calendar.DAY_OF_YEAR, 1)
        wm.enqueueUniquePeriodicWork("summary", ExistingPeriodicWorkPolicy.UPDATE,
            PeriodicWorkRequestBuilder<SummaryWorker>(24, TimeUnit.HOURS)
                .setInitialDelay(t.timeInMillis - now.timeInMillis, TimeUnit.MILLISECONDS).build())
    }
}

class UploadWorker(ctx: Context, p: WorkerParameters) : Worker(ctx, p) {
    override fun doWork(): Result {
        val c = applicationContext
        val id = inputData.getLong("id", 0L)
        val e = Store.find(c, id) ?: return Result.success()
        if (e.status == "sent") return Result.success()
        val r = Uploader.send(c, "sms.php", Uploader.payload(e), false)
        val tries = runAttemptCount + 1
        return when {
            r.ok -> { Store.markSent(c, id); Store.setConn(c, true, "OK"); Result.success() }
            r.error == null && (r.html || (r.code in 400..499 && r.code != 429 && r.code != 408)) -> {
                Store.update(c, id, "failed", Api.short(r), tries)   // ভুল key/URL: বারবার চেষ্টা করে লাভ নেই
                Store.setConn(c, false, Api.short(r))
                Notifier.failed(c, Api.short(r))
                Result.failure()
            }
            tries > 20 -> { Store.update(c, id, "failed", Api.short(r), tries); Notifier.failed(c, Api.short(r)); Result.failure() }
            else -> { Store.update(c, id, "pending", Api.short(r), tries); Result.retry() }
        }
    }
}

class PingWorker(ctx: Context, p: WorkerParameters) : Worker(ctx, p) {
    override fun doWork(): Result {
        val c = applicationContext
        if (Store.enabled(c) && Store.url(c).isNotEmpty()) {
            val r = Api.post(Store.url(c), Store.key(c), "ping.php", JSONObject())
            Store.setConn(c, r.ok, Api.verdict(r).msg)
        }
        return Result.success()
    }
}

class SummaryWorker(ctx: Context, p: WorkerParameters) : Worker(ctx, p) {
    override fun doWork(): Result {
        val c = applicationContext
        if (Store.summary(c)) {
            val s = Store.sumDays(c, 1)
            Notifier.summary(c, "FreePay: আজকের সারাংশ", "${s.count}টি পেমেন্ট • মোট ৳${Parser.fmt(s.amount)}")
        }
        return Result.success()
    }
}
