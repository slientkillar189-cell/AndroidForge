package com.freepay.sms

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

/** পেমেন্ট এলে ফোন মুখে বলে (Android এর বিল্ট-ইন TTS; বাংলা না থাকলে English)। */
object Speaker {
    fun bn(e: Store.Entry) = "${Parser.provider(e.sender)} থেকে ${Parser.fmt(e.amt)} টাকা পেয়েছেন"
    fun en(e: Store.Entry) = "Received ${Parser.fmt(e.amt)} taka from ${Parser.provider(e.sender)}"

    fun say(ctx: Context, bnText: String, enText: String, done: () -> Unit) {
        val app = ctx.applicationContext
        Handler(Looper.getMainLooper()).post {
            var tts: TextToSpeech? = null
            val fin = AtomicBoolean(false)
            val end = {
                if (fin.compareAndSet(false, true)) {
                    try { tts?.shutdown() } catch (e: Exception) { }
                    done()
                }
            }
            try {
                tts = TextToSpeech(app) { status ->
                    val t = tts
                    if (status != TextToSpeech.SUCCESS || t == null) {
                        end()
                    } else {
                        try {
                            val r = t.setLanguage(Locale("bn", "BD"))
                            val bnOk = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
                            if (!bnOk) t.setLanguage(Locale.ENGLISH)
                            t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                                override fun onStart(id: String?) {}
                                override fun onDone(id: String?) { end() }
                                @Deprecated("Deprecated in Java")
                                override fun onError(id: String?) { end() }
                            })
                            t.speak(if (bnOk) bnText else enText, TextToSpeech.QUEUE_FLUSH, null, "fp")
                        } catch (e: Exception) { end() }
                    }
                }
            } catch (e: Exception) { end() }
        }
    }
}
