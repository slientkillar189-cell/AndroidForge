package com.freepay.sms

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

/** নোটিফিকেশন (Android 13+ এ অনুমতি দিলে দেখাবে)। */
object Notifier {
    private fun post(ctx: Context, ch: String, chName: String, importance: Int, id: Int, title: String, text: String, icon: Int) {
        try {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(ch, chName, importance))
            val pi = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            @Suppress("DEPRECATION")
            val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(ctx, ch) else Notification.Builder(ctx)
            b.setSmallIcon(icon).setContentTitle(title).setContentText(text)
                .setStyle(Notification.BigTextStyle().bigText(text))
                .setContentIntent(pi).setAutoCancel(true)
            nm.notify(id, b.build())
        } catch (e: Exception) { }
    }

    fun failed(ctx: Context, msg: String) =
        post(ctx, "send_fail", "Send failures", NotificationManager.IMPORTANCE_DEFAULT, 1001,
            "FreePay SMS: পাঠানো যায়নি", msg, android.R.drawable.stat_notify_error)

    fun summary(ctx: Context, title: String, msg: String) =
        post(ctx, "daily_summary", "Daily summary", NotificationManager.IMPORTANCE_LOW, 1002,
            title, msg, android.R.drawable.stat_notify_chat)
}
