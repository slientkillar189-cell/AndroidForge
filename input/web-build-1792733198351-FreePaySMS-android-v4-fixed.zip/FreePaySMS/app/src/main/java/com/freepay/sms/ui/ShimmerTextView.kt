package com.freepay.sms.ui

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Shader
import android.os.SystemClock
import android.util.AttributeSet
import android.view.animation.LinearInterpolator
import android.widget.TextView

/** TextView with a flowing cyan → white → violet gradient. */
class ShimmerTextView @JvmOverloads constructor(
    ctx: Context, attrs: AttributeSet? = null, defStyle: Int = android.R.attr.textViewStyle
) : TextView(ctx, attrs, defStyle) {
    private var shader: LinearGradient? = null
    private val m = Matrix()
    private var shift = 0f
    private var last = 0L
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 3400; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener {
            shift = it.animatedValue as Float
            val now = SystemClock.uptimeMillis()
            if (now - last >= 50) { last = now; apply2() }   // ২০ fps যথেষ্ট
        }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        val len = w.toFloat().coerceAtLeast(1f)
        shader = LinearGradient(0f, 0f, len, 0f,
            intArrayOf(Color.rgb(0, 229, 255), Color.WHITE, Color.rgb(179, 136, 255)), null, Shader.TileMode.MIRROR)
        paint.shader = shader
        apply2()
    }

    private fun apply2() {
        shader?.let { m.setTranslate(shift * 2f * width, 0f); it.setLocalMatrix(m) }
        invalidate()
    }

    fun sync() { if (isAttachedToWindow) Fx.syncAnim(anim, Fx.animOk(context)) }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); Fx.syncAnim(anim, Fx.animOk(context)) }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }
    override fun onWindowVisibilityChanged(v: Int) {
        super.onWindowVisibilityChanged(v)
        if (v == VISIBLE) Fx.syncAnim(anim, Fx.animOk(context)) else if (anim.isRunning) anim.pause()
    }
}
