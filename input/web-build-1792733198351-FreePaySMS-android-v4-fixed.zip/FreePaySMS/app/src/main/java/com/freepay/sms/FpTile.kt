package com.freepay.sms

import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** Quick Settings টাইল: নোটিফিকেশন প্যানেল থেকেই SMS forwarding ON/OFF। */
class FpTile : TileService() {
    override fun onStartListening() { update() }
    override fun onClick() { Store.setEnabled(this, !Store.enabled(this)); update() }

    private fun update() {
        val t = qsTile ?: return
        t.label = "FreePay SMS"
        t.state = if (Store.enabled(this)) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.updateTile()
    }
}
