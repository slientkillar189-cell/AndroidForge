package com.freepay.sms

/** পেমেন্ট SMS থেকে টাকার অঙ্ক, TrxID, ইনকামিং কিনা ও প্রোভাইডার বের করে (আনুমানিক — ফরম্যাট বদলালে ভুল হতে পারে)। */
object Parser {
    data class Info(val amount: Double, val trx: String, val incoming: Boolean)

    private val amtRe = Regex("""(?:(?<![A-Za-z])(?:tk\.?|bdt)|৳|taka|টাকা)\s*:?\s*([0-9][0-9,]*(?:\.[0-9]{1,2})?)""", RegexOption.IGNORE_CASE)
    private val amtRe2 = Regex("""([0-9][0-9,]*(?:\.[0-9]{1,2})?)\s*(?:tk\b|taka|টাকা|৳)""", RegexOption.IGNORE_CASE)
    private val trxRe = Regex("""(?:trx\s*id|txn\s*id|transaction\s*id|ref(?:erence)?(?:\s*no)?)\s*[:#\-]?\s*([A-Za-z0-9]{6,20})""", RegexOption.IGNORE_CASE)
    private val inRe = Regex("""received|cash\s*in|credited|deposit|payment\s+from|পেয়েছেন|রিসিভ|জমা""", RegexOption.IGNORE_CASE)
    private val outRe = Regex("""you\s+have\s+sent|cash\s*out|send\s*money|payment\s+to|bill\s+pay|recharge|পাঠিয়েছেন|ক্যাশ\s*আউট""", RegexOption.IGNORE_CASE)

    private fun ascii(s: String): String {
        val sb = StringBuilder(s.length)
        for (ch in s) sb.append(if (ch in '০'..'৯') ('0' + (ch - '০')) else ch)
        return sb.toString()
    }

    fun parse(bodyRaw: String): Info {
        val body = ascii(bodyRaw)
        val m = amtRe.find(body) ?: amtRe2.find(body)
        val amt = m?.groupValues?.get(1)?.replace(",", "")?.toDoubleOrNull() ?: 0.0
        val trx = trxRe.find(body)?.groupValues?.get(1) ?: ""
        val incoming = inRe.containsMatchIn(body) && !outRe.containsMatchIn(body)
        return Info(amt, trx, incoming)
    }

    fun provider(sender: String): String {
        val s = sender.lowercase()
        return when {
            s.contains("bkash") -> "bKash"
            s.contains("nagad") -> "Nagad"
            s.contains("rocket") || s.contains("16216") -> "Rocket"
            s.contains("upay") -> "Upay"
            s.contains("cellfin") -> "Cellfin"
            s.contains("okwallet") || s.contains("ok wallet") -> "OK Wallet"
            s == "tap" || s.contains("tap") -> "Tap"
            else -> sender.take(12)
        }
    }

    fun fmt(x: Double): String =
        if (x == Math.floor(x)) String.format(java.util.Locale.US, "%,d", x.toLong()) else String.format(java.util.Locale.US, "%,.2f", x)
}
