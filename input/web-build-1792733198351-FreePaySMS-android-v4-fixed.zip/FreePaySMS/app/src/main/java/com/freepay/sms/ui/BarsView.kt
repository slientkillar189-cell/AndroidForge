package com.freepay.sms.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View

/** ৭ দিনের আয়ের সাধারণ বার চার্ট — কোনো অ্যানিমেশন নেই (ব্যাটারি-বান্ধব)। */
class BarsView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {
    private var data = DoubleArray(7)
    private var labels = Array(7) { "" }
    private val bar = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(0, 229, 255) }
    private val today = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(0, 230, 118) }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(154, 166, 204); textAlign = Paint.Align.CENTER }
    private val rect = RectF()

    fun set(d: DoubleArray, l: Array<String>) { data = d; labels = l; invalidate() }

    override fun onDraw(c: Canvas) {
        val n = data.size
        if (n == 0) return
        val dn = resources.displayMetrics.density
        txt.textSize = 10f * dn
        val w = width.toFloat(); val h = height.toFloat()
        val labelH = 16f * dn
        val maxV = (data.maxOrNull() ?: 0.0).coerceAtLeast(1.0)
        val slot = w / n
        val bw = slot * 0.5f
        for (i in 0 until n) {
            val bh = ((h - labelH - 4f * dn) * (data[i] / maxV)).toFloat().coerceAtLeast(if (data[i] > 0) 3f * dn else 1.5f * dn)
            val cx = slot * i + slot / 2
            rect.set(cx - bw / 2, h - labelH - bh, cx + bw / 2, h - labelH)
            c.drawRoundRect(rect, 4f * dn, 4f * dn, if (i == n - 1) today else bar)
            c.drawText(labels[i], cx, h - 3f * dn, txt)
        }
    }
}
