package com.freepay.sms

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.app.Activity
import android.app.KeyguardManager
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.freepay.sms.ui.AuroraView
import com.freepay.sms.ui.BarsView
import com.freepay.sms.ui.Fx
import com.freepay.sms.ui.PulseRingsView
import com.freepay.sms.ui.ShimmerTextView
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import android.os.Build

class MainActivity : Activity() {
    private lateinit var etUrl: EditText
    private lateinit var etKey: EditText
    private lateinit var etKw: EditText
    private lateinit var btnSave: TextView
    private lateinit var btnTest: TextView
    private lateinit var pb: ProgressBar
    private lateinit var eye: TextView
    private lateinit var dot: View
    private lateinit var tvConn: TextView
    private lateinit var tvLast: TextView
    private lateinit var chipPerm: TextView
    private lateinit var chipBat: TextView
    private lateinit var swEnable: Switch
    private lateinit var tvSent: TextView
    private lateinit var tvPending: TextView
    private lateinit var tvFailed: TextView
    private lateinit var resultBox: LinearLayout
    private lateinit var tvResTitle: TextView
    private lateinit var tvResMsg: TextView
    private lateinit var tvResDetail: TextView
    private lateinit var tvCopy: TextView
    private lateinit var logList: LinearLayout
    private lateinit var tvEmpty: TextView
    private lateinit var logo: ImageView

    private var dotAnim: ObjectAnimator? = null
    private lateinit var logoAnim: ObjectAnimator
    private lateinit var swLite: Switch
    private lateinit var swVoice: Switch
    private lateinit var swSummary: Switch
    private lateinit var swAmoled: Switch
    private lateinit var swLock: Switch
    private lateinit var etUrl2: EditText
    private lateinit var etKey2: EditText
    private lateinit var etSearch: EditText
    private var query = ""
    private var unlocked = false
    private var authBusy = false
    private var lastStop = 0L
    private var lastReport = ""
    private var testing = false
    private val shown = HashSet<Long>()
    private val df = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)

        etUrl = findViewById(R.id.etUrl); etKey = findViewById(R.id.etKey); etKw = findViewById(R.id.etKw)
        btnSave = findViewById(R.id.btnSave); btnTest = findViewById(R.id.btnTest); pb = findViewById(R.id.pb)
        eye = findViewById(R.id.eye); dot = findViewById(R.id.dot)
        tvConn = findViewById(R.id.tvConn); tvLast = findViewById(R.id.tvLast)
        chipPerm = findViewById(R.id.chipPerm); chipBat = findViewById(R.id.chipBat)
        swEnable = findViewById(R.id.swEnable); swLite = findViewById(R.id.swLite)
        swVoice = findViewById(R.id.swVoice); swSummary = findViewById(R.id.swSummary)
        swAmoled = findViewById(R.id.swAmoled); swLock = findViewById(R.id.swLock)
        etUrl2 = findViewById(R.id.etUrl2); etKey2 = findViewById(R.id.etKey2); etSearch = findViewById(R.id.etSearch)
        tvSent = findViewById(R.id.tvSent); tvPending = findViewById(R.id.tvPending); tvFailed = findViewById(R.id.tvFailed)
        resultBox = findViewById(R.id.resultBox); tvResTitle = findViewById(R.id.tvResTitle)
        tvResMsg = findViewById(R.id.tvResMsg); tvResDetail = findViewById(R.id.tvResDetail); tvCopy = findViewById(R.id.tvCopy)
        logList = findViewById(R.id.logList); tvEmpty = findViewById(R.id.tvEmpty); logo = findViewById(R.id.logo)

        etUrl.setText(Store.url(this)); etKey.setText(Store.key(this)); etKw.setText(Store.keywords(this))
        swEnable.isChecked = Store.enabled(this)
        swLite.isChecked = Store.lite(this)
        swVoice.isChecked = Store.speak(this); swSummary.isChecked = Store.summary(this)
        swAmoled.isChecked = Store.amoled(this); swLock.isChecked = Store.lock(this)
        etUrl2.setText(Store.url2(this)); etKey2.setText(Store.key2(this))
        findViewById<TextView>(R.id.tvVersion).text = "v" + try {
            packageManager.getPackageInfo(packageName, 0).versionName ?: "4.0"
        } catch (e: Exception) { "4.0" }

        var visible = false
        eye.setOnClickListener {
            visible = !visible
            etKey.transformationMethod = if (visible) HideReturnsTransformationMethod.getInstance() else PasswordTransformationMethod.getInstance()
            etKey.setSelection(etKey.text.length)
            eye.text = if (visible) "🙈" else "👁"
        }
        btnSave.setOnClickListener { Fx.tap(it); if (save()) runTest() }
        btnTest.setOnClickListener { Fx.tap(it); runTest() }
        swEnable.setOnCheckedChangeListener { _, on -> Store.setEnabled(this, on); Toast.makeText(this, if (on) "Forwarding ON" else "Forwarding OFF", Toast.LENGTH_SHORT).show() }
        swLite.setOnCheckedChangeListener { _, on ->
            Store.setLite(this, on); syncAnimations(); refreshAll()
            toast(if (on) "Lite mode ON — অ্যানিমেশন বন্ধ, ব্যাটারি সাশ্রয় 🔋" else "Lite mode OFF")
        }
        findViewById<View>(R.id.btnExport).setOnClickListener { Fx.tap(it); exportLog() }
        findViewById<View>(R.id.btnHealth).setOnClickListener { Fx.tap(it); showHealth() }
        findViewById<View>(R.id.btnVoice).setOnClickListener { Fx.tap(it); testVoice() }
        findViewById<View>(R.id.btnBackup).setOnClickListener { Fx.tap(it); backupSettings() }
        findViewById<View>(R.id.btnRestore).setOnClickListener { Fx.tap(it); restoreSettings() }
        swVoice.setOnCheckedChangeListener { b, on -> Store.setSpeak(this, on); if (on && b.isPressed) testVoice() }
        swSummary.setOnCheckedChangeListener { _, on ->
            Store.setSummary(this, on); Sched.summary(this, on)
            if (on) toast("রোজ রাত ৯টায় দিনের সারাংশ আসবে (নোটিফিকেশন অনুমতি লাগবে)")
        }
        swAmoled.setOnCheckedChangeListener { _, on -> Store.setAmoled(this, on); syncAnimations() }
        swLock.setOnCheckedChangeListener { _, on ->
            if (on) {
                val km = getSystemService(KEYGUARD_SERVICE) as KeyguardManager
                if (!km.isDeviceSecure) {
                    swLock.isChecked = false
                    toast("আগে ফোনে স্ক্রিন লক (PIN/প্যাটার্ন/ফিঙ্গারপ্রিন্ট) সেট করুন")
                    return@setOnCheckedChangeListener
                }
            }
            Store.setLock(this, on)
        }
        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { query = s?.toString()?.trim()?.lowercase() ?: ""; refreshLog() }
        })
        chipPerm.setOnClickListener { Fx.tap(it); if (granted()) toast("SMS অনুমতি আছে ✓") else requestPermissions(arrayOf(Manifest.permission.RECEIVE_SMS), 1) }
        chipBat.setOnClickListener { Fx.tap(it); askBattery(true) }
        findViewById<View>(R.id.btnBattery).setOnClickListener { Fx.tap(it); askBattery(true) }
        findViewById<View>(R.id.btnApp).setOnClickListener { Fx.tap(it); openAppSettings() }
        findViewById<View>(R.id.btnHelp).setOnClickListener { Fx.tap(it); showHelp() }
        findViewById<View>(R.id.btnRetry).setOnClickListener { Fx.tap(it); retryFailed() }
        findViewById<View>(R.id.btnClear).setOnClickListener {
            Fx.tap(it)
            AlertDialog.Builder(this).setTitle("Activity মুছবেন?").setMessage("শুধু ফোনের লগ মুছবে, সার্ভারের ডেটা নয়।")
                .setPositiveButton("মুছুন") { _, _ -> shown.clear(); Store.clear(this) }.setNegativeButton("না", null).show()
        }
        tvCopy.setOnClickListener {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("FreePay SMS", lastReport)); toast("Copied ✓")
        }

        listOf(btnSave, btnTest, chipPerm, chipBat, eye, tvCopy,
            findViewById<View>(R.id.btnBattery), findViewById<View>(R.id.btnApp), findViewById<View>(R.id.btnHelp),
            findViewById<View>(R.id.btnRetry), findViewById<View>(R.id.btnClear)).forEach { Fx.pressable(it) }

        // ---- entrance animations ----
        if (Fx.animOk(this)) {
            logo.scaleX = 0f; logo.scaleY = 0f; logo.rotation = -180f
            logo.animate().scaleX(1f).scaleY(1f).rotation(0f).setDuration(900).setInterpolator(OvershootInterpolator(1.6f)).start()
        }
        logoAnim = ObjectAnimator.ofFloat(logo, View.TRANSLATION_Y, 0f, -Fx.dp(this, 7f), 0f).apply {
            duration = 3200; startDelay = 1000; repeatCount = ObjectAnimator.INFINITE
            interpolator = AccelerateDecelerateInterpolator()
        }
        Fx.enter(listOf<View>(findViewById<View>(R.id.brand), findViewById<View>(R.id.tagline), findViewById<View>(R.id.statusCard),
            findViewById<View>(R.id.statsRow), findViewById<View>(R.id.configCard), findViewById<View>(R.id.logCard),
            findViewById<View>(R.id.toolsCard), findViewById<View>(R.id.footer)), 250L)

        if (Store.summary(this)) Sched.summary(this, true)
        if (Store.url(this).isNotEmpty()) schedulePing()   // পুরনো ১৫-মিনিটের ping কে নতুন ৬০-মিনিটে বদলায়
        refreshAll()
    }

    override fun onStart() {
        super.onStart()
        if (unlocked && System.currentTimeMillis() - lastStop > 30000) unlocked = false   // ৩০ সেকেন্ডের বেশি বাইরে থাকলে আবার লক
        Store.listener = { runOnUiThread { if (!isFinishing && !isDestroyed) { refreshStats(); refreshLog(); refreshConn() } } }
        refreshAll()
    }

    override fun onStop() {
        Store.listener = null
        lastStop = System.currentTimeMillis()
        // ব্যাকগ্রাউন্ডে কোনো অ্যানিমেশন চলবে না
        logoAnim.cancel(); logo.translationY = 0f
        dotAnim?.cancel(); dot.scaleX = 1f; dot.scaleY = 1f; dot.alpha = 1f
        super.onStop()
    }
    override fun onResume() { super.onResume(); checkLock(); refreshStatus(); syncAnimations() }

    // ------------------------------------------------------------------ অ্যাপ লক (ফোনের স্ক্রিন লক ব্যবহার করে)
    @Suppress("DEPRECATION")
    private fun checkLock() {
        val content = findViewById<View>(android.R.id.content)
        if (!Store.lock(this) || unlocked) { content.visibility = View.VISIBLE; return }
        content.visibility = View.INVISIBLE
        if (authBusy) return
        val km = getSystemService(KEYGUARD_SERVICE) as KeyguardManager
        val i = if (km.isDeviceSecure) km.createConfirmDeviceCredentialIntent("FreePay SMS", "অ্যাপ খুলতে ফোনের লক দিন") else null
        if (i == null) { unlocked = true; content.visibility = View.VISIBLE; return }
        authBusy = true
        startActivityForResult(i, 77)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 77) {
            authBusy = false
            if (res == RESULT_OK) { unlocked = true; findViewById<View>(android.R.id.content).visibility = View.VISIBLE }
            else finish()
        }
    }

    /** Lite mode / Battery Saver / কম ব্যাটারি অনুযায়ী সব অ্যানিমেশন চালু-বন্ধ */
    private fun syncAnimations() {
        val on = Fx.animOk(this)
        findViewById<AuroraView>(R.id.aurora).sync()
        findViewById<PulseRingsView>(R.id.pulse).sync()
        findViewById<ShimmerTextView>(R.id.brand).sync()
        Fx.syncAnim(logoAnim, on)
        if (!on) { logo.translationY = 0f }
    }

    // ------------------------------------------------------------------ actions
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun save(): Boolean {
        val base = Api.normalizeBase(etUrl.text.toString())
        val key = etKey.text.toString().trim()
        if (base.isEmpty()) { Fx.shake(etUrl); toast("Server URL দিন"); return false }
        if (key.isEmpty()) { Fx.shake(etKey); toast("Device key দিন"); return false }
        etUrl.setText(base)
        Store.saveConfig(this, base, key, etKw.text.toString().trim())
        val b2 = Api.normalizeBase(etUrl2.text.toString())
        Store.saveBackup(this, b2, etKey2.text.toString().trim()); etUrl2.setText(b2)
        if (base.startsWith("http://", true)) toast("সতর্কতা: http:// এ key এনক্রিপ্ট ছাড়া যায় — https ভালো")
        startWork()
        return true
    }

    private fun schedulePing() = Sched.ping(this)

    private fun startWork() {
        schedulePing()
        if (granted()) askBattery(false)
        else if (Build.VERSION.SDK_INT >= 33)
            requestPermissions(arrayOf(Manifest.permission.RECEIVE_SMS, "android.permission.POST_NOTIFICATIONS"), 1)
        else requestPermissions(arrayOf(Manifest.permission.RECEIVE_SMS), 1)
    }

    /** লগ CSV আকারে শেয়ার/সেভ */
    private fun exportLog() {
        val list = Store.entries(this)
        if (list.isEmpty()) { toast("এক্সপোর্ট করার মতো লগ নেই"); return }
        fun q(x: String) = "\"" + x.replace("\"", "\"\"").replace("\n", " ") + "\""
        val sb = StringBuilder("time,sender,status,sim,tries,body\n")
        list.forEach { sb.append(q(df.format(Date(it.ts)))).append(',').append(q(it.sender)).append(',').append(it.status)
            .append(',').append(it.sim).append(',').append(it.tries).append(',').append(q(it.body)).append('\n') }
        try {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain")
                .putExtra(Intent.EXTRA_SUBJECT, "FreePay SMS log").putExtra(Intent.EXTRA_TEXT, sb.toString()), "Export log"))
        } catch (e: Exception) { toast("শেয়ার করা যায়নি") }
    }

    /** FIX: tests with what is typed in the fields right now (old code used saved values only). */
    private fun runTest() {
        if (testing) return
        val base = Api.normalizeBase(etUrl.text.toString())
        val key = etKey.text.toString().trim()
        if (base.isEmpty()) { Fx.shake(etUrl); toast("আগে Server URL দিন"); return }
        if (key.isEmpty()) { Fx.shake(etKey); toast("আগে Device key দিন"); return }
        setTesting(true)
        Thread {
            val r = Api.post(base, key, "ping.php", JSONObject())
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                setTesting(false)
                showResult(r)
            }
        }.start()
    }

    private fun setTesting(on: Boolean) {
        testing = on
        pb.visibility = if (on) View.VISIBLE else View.GONE
        btnTest.text = if (on) "Testing…" else "🔌  Test connection"
        btnTest.alpha = if (on) 0.6f else 1f
        btnSave.alpha = if (on) 0.6f else 1f
        if (on) { tvConn.text = "Checking…"; setDot(Color.parseColor("#FFB020"), true) }
    }

    private fun showResult(r: ApiResult) {
        val v = Api.verdict(r)
        val col = Color.parseColor(if (v.ok) "#00E676" else "#FF5470")
        resultBox.background = Fx.box(this, col, 14f)
        tvResTitle.text = (if (v.ok) "✅  " else "❌  ") + v.title
        tvResTitle.setTextColor(col)
        tvResMsg.text = v.msg
        val detail = "URL: ${r.url}\nHTTP: ${r.code}   Time: ${r.ms} ms" +
            (if (r.body.isNotEmpty()) "\nResponse: ${r.body.take(160)}" else "")
        tvResDetail.text = detail
        lastReport = "${v.title}\n${v.msg}\n$detail"
        resultBox.visibility = View.VISIBLE
        resultBox.alpha = 0f; resultBox.translationY = -Fx.dp(this, 16f)
        resultBox.animate().alpha(1f).translationY(0f).setDuration(380).setInterpolator(DecelerateInterpolator(2f)).start()
        Store.setConn(this, v.ok, v.msg)
        if (v.ok) {
            logo.animate().rotationBy(360f).setDuration(900).setInterpolator(DecelerateInterpolator()).start()
            Fx.bounce(findViewById<View>(R.id.statusCard))
        } else Fx.shake(btnTest)
        refreshConn()
    }

    private fun retryFailed() {
        val failed = Store.entries(this).filter { it.status == "failed" }
        if (failed.isEmpty()) { toast("কোনো failed SMS নেই"); return }
        val net = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
        failed.forEach {
            Store.update(this, it.id, "pending", "", 0)
            WorkManager.getInstance(this).enqueue(OneTimeWorkRequestBuilder<UploadWorker>()
                .setInputData(workDataOf("id" to it.id)).setConstraints(net)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS).build())
        }
        toast("${failed.size}টি SMS আবার পাঠানো হচ্ছে…")
    }

    // ------------------------------------------------------------------ permissions
    private fun granted() = checkSelfPermission(Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED
    private fun batteryOk() = (getSystemService(POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)

    private fun askBattery(force: Boolean) {
        if (batteryOk()) { if (force) toast("Battery unrestricted ✓"); return }
        try {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        } catch (e: ActivityNotFoundException) {
            try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (e2: Exception) { openAppSettings() }
        }
    }

    private fun openAppSettings() {
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(c, p, r)
        refreshStatus()
        if (c == 2) return
        if (r.firstOrNull() == PackageManager.PERMISSION_GRANTED) askBattery(false)
        else AlertDialog.Builder(this).setTitle("SMS অনুমতি লাগবে")
            .setMessage("Android 13+ এ APK বাইরে থেকে ইনস্টল করলে অনুমতি ধূসর থাকতে পারে।\n\nApp settings → ⋮ → Allow restricted settings, তারপর SMS অনুমতি দিন।")
            .setPositiveButton("App settings") { _, _ -> openAppSettings() }.setNegativeButton("পরে", null).show()
    }

    private fun showHelp() {
        AlertDialog.Builder(this).setTitle("Setup guide")
            .setMessage("1. Server URL দিন: https://yourdomain.com/freepay\n2. Device key দিন (config.php → device_key)\n3. Save & start চাপুন, SMS অনুমতি ও Battery \"Unrestricted\" দিন\n4. Test connection এ ✅ দেখুন\n\nTest ব্যর্থ হলে লাল বক্সে আসল কারণ লেখা থাকবে — 📋 Copy details করে পাঠাতে পারেন।\n\nXiaomi/Oppo/Vivo/Samsung এ Auto-start ও Background চালু রাখুন। পেমেন্টের সিমটি এই ফোনে থাকতে হবে।\n\n— CHAKRABORTY IT LTD")
            .setPositiveButton("OK", null).show()
    }

    // ------------------------------------------------------------------ UI refresh
    private fun refreshAll() { refreshStatus(); refreshStats(); refreshLog(); refreshConn() }

    private fun refreshStatus() {
        val g = granted(); val bt = batteryOk()
        styleChip(chipPerm, if (g) "📩 SMS অনুমতি ✓" else "📩 SMS অনুমতি ✕", g)
        styleChip(chipBat, if (bt) "🔋 Battery ✓" else "🔋 Battery ✕", bt)
    }

    private fun styleChip(t: TextView, text: String, ok: Boolean) {
        val col = Color.parseColor(if (ok) "#00E676" else "#FF5470")
        t.text = text; t.setTextColor(col); t.background = Fx.box(this, col, 14f, 28)
    }

    private fun refreshStats() {
        val list = Store.entries(this)
        Fx.countUp(tvSent, Store.sentTotal(this))
        Fx.countUp(tvPending, list.count { it.status == "pending" })
        Fx.countUp(tvFailed, list.count { it.status == "failed" })
        refreshDash()
    }

    private fun refreshDash() {
        fun fill(id: Int, subId: Int, s: Store.Sum, label: String) {
            findViewById<TextView>(id).text = "৳" + Parser.fmt(s.amount)
            findViewById<TextView>(subId).text = "$label • ${s.count}টি"
        }
        fill(R.id.tvToday, R.id.tvTodaySub, Store.sumDays(this, 1), "আজ")
        fill(R.id.tvWeek, R.id.tvWeekSub, Store.sumDays(this, 7), "৭ দিন")
        fill(R.id.tvMonth, R.id.tvMonthSub, Store.sumDays(this, 30), "৩০ দিন")
        val f = SimpleDateFormat("d", Locale.getDefault())
        val now = System.currentTimeMillis()
        val labels = Array(7) { i -> f.format(Date(now - (6 - i) * 86400000L)) }
        findViewById<BarsView>(R.id.bars).set(Store.perDay(this, 7), labels)
        val prov = Store.byProvider(this, 30)
        findViewById<TextView>(R.id.tvProv).text =
            if (prov.isEmpty()) "এখনো হিসাবে কিছু আসেনি (শুধু সফলভাবে পাঠানো ইনকামিং পেমেন্ট SMS গোনা হয়)"
            else "৩০ দিন: " + prov.entries.joinToString("   ") { "${it.key} ৳${Parser.fmt(it.value.amount)}" }
    }

    private fun refreshConn() {
        val ts = Store.connTs(this)
        when (Store.connState(this)) {
            1 -> { if (!testing) tvConn.text = "Connected"; if (!testing) setDot(Color.parseColor("#00E676"), true) }
            2 -> { if (!testing) tvConn.text = "Disconnected"; if (!testing) setDot(Color.parseColor("#FF5470"), false) }
            else -> { if (!testing) tvConn.text = "Not tested yet"; if (!testing) setDot(Color.parseColor("#6F7BA6"), false) }
        }
        tvLast.text = if (ts > 0) "checked " + ago(ts) else "—"
    }

    private fun ago(ts: Long): String {
        val s = (System.currentTimeMillis() - ts) / 1000
        return when {
            s < 60 -> "just now"
            s < 3600 -> "${s / 60}m ago"
            s < 86400 -> "${s / 3600}h ago"
            else -> df.format(Date(ts))
        }
    }

    private fun setDot(color: Int, pulse: Boolean) {
        dotAnim?.cancel(); dot.scaleX = 1f; dot.scaleY = 1f; dot.alpha = 1f
        dot.backgroundTintList = ColorStateList.valueOf(color)
        tvConn.setTextColor(color)
        if (pulse && Fx.animOk(this)) {
            dotAnim = ObjectAnimator.ofPropertyValuesHolder(dot,
                PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.7f, 1f),
                PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.7f, 1f),
                PropertyValuesHolder.ofFloat(View.ALPHA, 1f, 0.45f, 1f)).apply {
                duration = 1400; repeatCount = ObjectAnimator.INFINITE; start()
            }
        }
    }

    // ------------------------------------------------------------------ Health check
    private fun showHealth() {
        toast("চেক করা হচ্ছে…")
        Thread {
            val base = Store.url(this); val key = Store.key(this)
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
            val net = cm.activeNetwork != null
            var serverOk = false
            var serverMsg = "URL/key দেওয়া নেই"
            if (!net) serverMsg = "ইন্টারনেট নেই"
            else if (base.isNotEmpty() && key.isNotEmpty()) {
                val r = Api.post(base, key, "ping.php", JSONObject())
                serverOk = r.ok; serverMsg = Api.verdict(r).title
                Store.setConn(this, r.ok, Api.verdict(r).msg)
            }
            val notifOk = Build.VERSION.SDK_INT < 33 ||
                checkSelfPermission("android.permission.POST_NOTIFICATIONS") == PackageManager.PERMISSION_GRANTED
            val items = listOf(
                Pair(granted(), "SMS অনুমতি"),
                Pair(Store.enabled(this), "Forwarding চালু"),
                Pair(base.isNotEmpty() && key.isNotEmpty(), "Server URL ও Device key দেওয়া"),
                Pair(net, "ইন্টারনেট"),
                Pair(serverOk, "সার্ভার সংযোগ ($serverMsg)"),
                Pair(batteryOk(), "Battery Unrestricted"),
                Pair(notifOk, "নোটিফিকেশন অনুমতি"),
                Pair(Store.keywords(this).isNotBlank(), "Sender keywords আছে")
            )
            val good = items.count { it.first }
            val msg = items.joinToString("\n") { (if (it.first) "✅  " else "❌  ") + it.second }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                val d = AlertDialog.Builder(this).setTitle("🩺 Health: $good/${items.size} ঠিক").setMessage(msg)
                    .setNegativeButton("বন্ধ", null)
                if (good < items.size) d.setPositiveButton("🔧 Fix") { _, _ -> fixFirst(base, key, notifOk) }
                d.show()
            }
        }.start()
    }

    /** প্রথম যে সমস্যাটি পাওয়া যায় সেটি ঠিক করার পথ দেখায়; আবার Health check চালিয়ে পরেরটি ঠিক করুন */
    private fun fixFirst(base: String, key: String, notifOk: Boolean) {
        when {
            !granted() -> requestPermissions(arrayOf(Manifest.permission.RECEIVE_SMS), 1)
            !Store.enabled(this) -> swEnable.isChecked = true
            base.isEmpty() || key.isEmpty() -> { etUrl.requestFocus(); toast("Server URL ও Device key দিয়ে Save চাপুন") }
            !batteryOk() -> askBattery(true)
            !notifOk -> requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 2)
            else -> toast("সার্ভার সংযোগ ঠিক করতে URL/key মিলিয়ে Test connection চাপুন")
        }
    }

    private fun testVoice() {
        val e = Store.Entry(0L, "bKash", "", 0L, "sent", "", 0, 0, 500.0, "")
        Speaker.say(this, Speaker.bn(e), Speaker.en(e)) { }
        toast("🔊 টেস্ট ভয়েস…")
    }

    // ------------------------------------------------------------------ Backup / Restore (ক্লিপবোর্ডে)
    private fun backupSettings() {
        val j = JSONObject().put("app", "freepay-sms").put("v", 4)
            .put("url", Store.url(this)).put("key", Store.key(this)).put("kw", Store.keywords(this))
            .put("url2", Store.url2(this)).put("key2", Store.key2(this))
            .put("speak", Store.speak(this)).put("summary", Store.summary(this))
            .put("amoled", Store.amoled(this)).put("lite", Store.lite(this))
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("FreePay SMS backup", j.toString()))
        AlertDialog.Builder(this).setTitle("Backup কপি হয়েছে ✓")
            .setMessage("সেটিংস (Device key সহ) ক্লিপবোর্ডে কপি হয়েছে। কোনো নিরাপদ নোটে পেস্ট করে রাখুন, কারো সাথে শেয়ার করবেন না।\n\nনতুন ফোনে সেই লেখা কপি করে ♻️ Restore চাপুন।")
            .setPositiveButton("OK", null).show()
    }

    private fun restoreSettings() {
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val txt = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString() ?: ""
            val j = JSONObject(txt)
            if (j.optString("app") != "freepay-sms") { toast("ক্লিপবোর্ডে বৈধ backup নেই"); return }
            Store.saveConfig(this, j.optString("url"), j.optString("key"), j.optString("kw", Store.DEFAULT_KW))
            Store.saveBackup(this, j.optString("url2"), j.optString("key2"))
            etUrl.setText(Store.url(this)); etKey.setText(Store.key(this)); etKw.setText(Store.keywords(this))
            etUrl2.setText(Store.url2(this)); etKey2.setText(Store.key2(this))
            swVoice.isChecked = j.optBoolean("speak"); swSummary.isChecked = j.optBoolean("summary")
            swAmoled.isChecked = j.optBoolean("amoled"); swLite.isChecked = j.optBoolean("lite")
            if (Store.url(this).isNotEmpty()) schedulePing()
            toast("Restore হয়েছে ✓")
        } catch (e: Exception) { toast("Restore ব্যর্থ — আগে সঠিক backup লেখা কপি করুন") }
    }

    private fun refreshLog() {
        val all = Store.entries(this).reversed()
        val list = (if (query.isEmpty()) all else all.filter {
            (it.sender + " " + it.body + " " + it.trx + " " + it.amt.toLong() + " " + it.status).lowercase().contains(query)
        }).take(30)
        logList.removeAllViews()
        tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        val newIds = HashSet<Long>()
        list.forEachIndexed { idx, e ->
            val row = layoutInflater.inflate(R.layout.item_log, logList, false)
            val col = Color.parseColor(when (e.status) { "sent" -> "#00E676"; "failed" -> "#FF5470"; else -> "#FFB020" })
            val icon = row.findViewById<TextView>(R.id.logIcon)
            icon.text = when (e.status) { "sent" -> "✓"; "failed" -> "✕"; else -> "⏳" }
            icon.setTextColor(col); icon.background = Fx.circle(col)
            row.findViewById<TextView>(R.id.logSender).text = if (e.sim > 0) e.sender + "  •  SIM" + e.sim else e.sender
            row.findViewById<TextView>(R.id.logBody).text = e.body.replace('\n', ' ').take(120)
            row.findViewById<TextView>(R.id.logMeta).text = df.format(Date(e.ts)) + (if (e.amt > 0) "  •  ৳" + Parser.fmt(e.amt) else "") +
                (if (e.status != "sent" && e.note.isNotEmpty()) "  •  " + e.note.take(70) else "")
            val st = row.findViewById<TextView>(R.id.logStatus)
            st.text = when (e.status) { "sent" -> "Sent"; "failed" -> "Failed"; else -> "Pending" }
            st.setTextColor(col)
            row.setOnClickListener {
                Fx.tap(it)
                AlertDialog.Builder(this).setTitle(e.sender)
                    .setMessage(e.body + "\n\n" + df.format(Date(e.ts)) + "  •  " + st.text +
                        (if (e.note.isNotEmpty()) "\n" + e.note else ""))
                    .setPositiveButton("OK", null).show()
            }
            Fx.pressable(row)
            logList.addView(row)
            if (e.id !in shown && Fx.animOk(this)) {
                row.alpha = 0f; row.translationX = -Fx.dp(this, 40f)
                row.animate().alpha(1f).translationX(0f).setStartDelay(idx * 50L).setDuration(380)
                    .setInterpolator(DecelerateInterpolator(2f)).start()
            }
            newIds.add(e.id)
        }
        shown.clear(); shown.addAll(newIds)
    }
}
