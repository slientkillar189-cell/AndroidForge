package com.freepay.sms.ui

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.os.SystemClock
import com.freepay.sms.Store
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sin

/** Animated background: drifting colour blobs + twinkling rising stars. */
class AuroraView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {
    private class Blob(val cx: Float, val cy: Float, val ax: Float, val ay: Float, val kx: Int, val ky: Int,
                       val ph: Float, val r: Float, val color: Int)

    private val blobs = listOf(
        Blob(0.15f, 0.12f, 0.20f, 0.08f, 1, 2, 0.00f, 0.70f, Color.rgb(124, 77, 255)),
        Blob(0.90f, 0.45f, 0.15f, 0.12f, 2, 1, 0.30f, 0.65f, Color.rgb(0, 184, 212)),
        Blob(0.30f, 0.95f, 0.25f, 0.06f, 1, 1, 0.60f, 0.60f, Color.rgb(255, 64, 129))
    )
    private val shaders = arrayOfNulls<RadialGradient>(3)
    private val radii = FloatArray(3)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val starPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val rnd = java.util.Random(7)
    private val stars = Array(45) { floatArrayOf(rnd.nextFloat(), rnd.nextFloat(), rnd.nextFloat(), 0.6f + rnd.nextFloat() * 1.4f) }
    private var t = 0f
    private var last = 0L
    private var black = false
    private fun isBlack(): Boolean { black = Store.amoled(context); return black }
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 24000; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener {
            t = it.animatedValue as Float
            val now = SystemClock.uptimeMillis()
            if (now - last >= 33) { last = now; invalidate() }   // ৩০ fps সীমা → ব্যাটারি/GPU কম
        }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        val m = max(w, h).toFloat()
        blobs.forEachIndexed { i, b ->
            radii[i] = b.r * m
            val c = b.color
            shaders[i] = RadialGradient(0f, 0f, radii[i],
                intArrayOf(Color.argb(95, Color.red(c), Color.green(c), Color.blue(c)), Color.argb(0, Color.red(c), Color.green(c), Color.blue(c))),
                null, Shader.TileMode.CLAMP)
        }
    }

    override fun onDraw(canvas: Canvas) {
        if (black) { canvas.drawColor(Color.BLACK); return }   // AMOLED: পিউর কালো = পিক্সেল বন্ধ
        canvas.drawColor(Color.rgb(7, 11, 26))
        val w = width.toFloat(); val h = height.toFloat()
        blobs.forEachIndexed { i, b ->
            val x = (b.cx + b.ax * sin(2 * PI * (t * b.kx + b.ph)).toFloat()) * w
            val y = (b.cy + b.ay * sin(2 * PI * (t * b.ky + b.ph + 0.25)).toFloat()) * h
            paint.shader = shaders[i]
            canvas.save(); canvas.translate(x, y); canvas.drawCircle(0f, 0f, radii[i], paint); canvas.restore()
        }
        paint.shader = null
        val d = resources.displayMetrics.density
        for (s in stars) {
            val y = (((s[1] - t) % 1f) + 1f) % 1f
            val tw = 0.25f + 0.75f * abs(sin(2 * PI * (t * 6 + s[2]))).toFloat()
            starPaint.alpha = (tw * 150).toInt()
            canvas.drawCircle(s[0] * w, y * h, s[3] * d, starPaint)
        }
    }

    fun sync() { if (isAttachedToWindow) { Fx.syncAnim(anim, !isBlack() && Fx.animOk(context)); invalidate() } }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); Fx.syncAnim(anim, !isBlack() && Fx.animOk(context)) }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }
    override fun onWindowVisibilityChanged(v: Int) {
        super.onWindowVisibilityChanged(v)
        if (v == VISIBLE) Fx.syncAnim(anim, !isBlack() && Fx.animOk(context)) else if (anim.isRunning) anim.pause()
    }
}
