package com.freepay.sms.ui

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.os.BatteryManager
import android.os.PowerManager
import android.provider.Settings
import com.freepay.sms.Store
import android.graphics.drawable.GradientDrawable
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.TextView

object Fx {
    fun dp(ctx: Context, x: Float): Float = x * ctx.resources.displayMetrics.density

    /** অ্যানিমেশন চলবে কিনা: Lite mode / Battery Saver / ব্যাটারি <30% (চার্জ ছাড়া) / সিস্টেমে animation বন্ধ হলে চলবে না */
    fun animOk(ctx: Context): Boolean {
        try {
            if (Store.lite(ctx)) return false
            val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
            if (pm.isPowerSaveMode) return false
            val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            val cap = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            if (cap in 1..29 && !bm.isCharging) return false
            val scale = Settings.Global.getFloat(ctx.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f)
            return scale != 0f
        } catch (e: Exception) { return true }
    }

    fun syncAnim(a: android.animation.Animator, on: Boolean) {
        if (on) { if (!a.isStarted) a.start() else if (a.isPaused) a.resume() }
        else if (a.isStarted) a.cancel()
    }

    fun enter(views: List<View>, baseDelay: Long = 150) {
        if (views.isNotEmpty() && !animOk(views[0].context)) return
        views.forEachIndexed { i, v ->
            v.alpha = 0f
            v.translationY = dp(v.context, 40f)
            v.animate().alpha(1f).translationY(0f).setStartDelay(baseDelay + i * 90L)
                .setDuration(520).setInterpolator(DecelerateInterpolator(2f)).start()
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    fun pressable(v: View) {
        v.setOnTouchListener { view, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> view.animate().scaleX(0.96f).scaleY(0.96f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    view.animate().scaleX(1f).scaleY(1f).setDuration(200).setInterpolator(OvershootInterpolator(2.5f)).start()
            }
            false
        }
    }

    fun tap(v: View) { v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY) }

    fun shake(v: View) {
        val d = dp(v.context, 1f)
        ObjectAnimator.ofFloat(v, View.TRANSLATION_X, 0f, -12f * d, 12f * d, -8f * d, 8f * d, -4f * d, 4f * d, 0f)
            .setDuration(420).start()
    }

    fun bounce(v: View) {
        v.animate().scaleX(1.03f).scaleY(1.03f).setDuration(140).withEndAction {
            v.animate().scaleX(1f).scaleY(1f).setDuration(300).setInterpolator(OvershootInterpolator(3f)).start()
        }.start()
    }

    fun countUp(tv: TextView, to: Int) {
        val from = (tv.tag as? Int) ?: 0
        tv.tag = to
        if (from == to || !animOk(tv.context)) { tv.text = to.toString(); return }
        ValueAnimator.ofInt(from, to).apply {
            duration = 600
            addUpdateListener { tv.text = (it.animatedValue as Int).toString() }
        }.start()
    }

    /** Translucent rounded box tinted with [color] (used for result panel, chips, log icons). */
    fun box(ctx: Context, color: Int, radiusDp: Float, fillAlpha: Int = 34): GradientDrawable {
        val r = color shr 16 and 0xFF; val g = color shr 8 and 0xFF; val b = color and 0xFF
        return GradientDrawable().apply {
            cornerRadius = dp(ctx, radiusDp)
            setColor(android.graphics.Color.argb(fillAlpha, r, g, b))
            setStroke(dp(ctx, 1f).toInt().coerceAtLeast(1), android.graphics.Color.argb(150, r, g, b))
        }
    }

    fun circle(color: Int): GradientDrawable {
        val r = color shr 16 and 0xFF; val g = color shr 8 and 0xFF; val b = color and 0xFF
        return GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(android.graphics.Color.argb(46, r, g, b)) }
    }
}
