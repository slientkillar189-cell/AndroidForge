package com.freepay.sms

import android.content.ComponentName
import android.content.Context
import android.content.SharedPreferences
import android.service.quicksettings.TileService
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.ArrayList
import java.util.Date
import java.util.Locale

object Store {
    const val DEFAULT_KW = "bkash,nagad,rocket,16216,upay,cellfin,tap,okwallet,ok wallet"
    private const val MAX = 100

    data class Entry(val id: Long, val sender: String, val body: String, val ts: Long,
                     var status: String, var note: String, var tries: Int, var sim: Int = 0,
                     var amt: Double = 0.0, var trx: String = "")

    data class Sum(val count: Int, val amount: Double)

    @Volatile var listener: (() -> Unit)? = null

    fun prefs(ctx: Context): SharedPreferences = ctx.applicationContext.getSharedPreferences("cfg", Context.MODE_PRIVATE)
    fun url(ctx: Context): String = prefs(ctx).getString("url", "") ?: ""
    fun key(ctx: Context): String = prefs(ctx).getString("key", "") ?: ""
    fun url2(ctx: Context): String = prefs(ctx).getString("url2", "") ?: ""
    fun key2(ctx: Context): String = prefs(ctx).getString("key2", "") ?: ""
    fun keywords(ctx: Context): String = prefs(ctx).getString("kw", DEFAULT_KW) ?: DEFAULT_KW
    fun enabled(ctx: Context): Boolean = prefs(ctx).getBoolean("enabled", true)

    fun setEnabled(ctx: Context, on: Boolean) {
        prefs(ctx).edit().putBoolean("enabled", on).apply()
        FpWidget.refresh(ctx)
        try { TileService.requestListeningState(ctx.applicationContext, ComponentName(ctx.applicationContext, FpTile::class.java)) } catch (e: Exception) { }
    }

    private fun flag(ctx: Context, k: String, def: Boolean = false) = prefs(ctx).getBoolean(k, def)
    private fun setFlag(ctx: Context, k: String, v: Boolean) { prefs(ctx).edit().putBoolean(k, v).apply() }
    fun lite(ctx: Context) = flag(ctx, "lite");       fun setLite(ctx: Context, v: Boolean) = setFlag(ctx, "lite", v)
    fun speak(ctx: Context) = flag(ctx, "speak");     fun setSpeak(ctx: Context, v: Boolean) = setFlag(ctx, "speak", v)
    fun amoled(ctx: Context) = flag(ctx, "amoled");   fun setAmoled(ctx: Context, v: Boolean) = setFlag(ctx, "amoled", v)
    fun lock(ctx: Context) = flag(ctx, "lock");       fun setLock(ctx: Context, v: Boolean) = setFlag(ctx, "lock", v)
    fun summary(ctx: Context) = flag(ctx, "summary"); fun setSummary(ctx: Context, v: Boolean) = setFlag(ctx, "summary", v)

    fun saveConfig(ctx: Context, url: String, key: String, kw: String) {
        prefs(ctx).edit().putString("url", url).putString("key", key).putString("kw", kw).apply()
    }
    fun saveBackup(ctx: Context, url2: String, key2: String) {
        prefs(ctx).edit().putString("url2", url2).putString("key2", key2).apply()
    }

    fun sentTotal(ctx: Context): Int = prefs(ctx).getInt("sent_total", 0)
    fun connState(ctx: Context): Int = prefs(ctx).getInt("conn", 0)       // 0 unknown, 1 ok, 2 failed
    fun connTs(ctx: Context): Long = prefs(ctx).getLong("conn_ts", 0L)

    fun setConn(ctx: Context, ok: Boolean, msg: String) {
        prefs(ctx).edit().putInt("conn", if (ok) 1 else 2).putLong("conn_ts", System.currentTimeMillis())
            .putString("conn_msg", msg).apply()
        listener?.invoke()
    }

    @Synchronized fun entries(ctx: Context): MutableList<Entry> {
        val out = ArrayList<Entry>()
        try {
            val arr = JSONArray(prefs(ctx).getString("log", "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Entry(o.getLong("id"), o.optString("s"), o.optString("b"), o.optLong("t"),
                    o.optString("st", "pending"), o.optString("n"), o.optInt("tr"), o.optInt("sm"),
                    o.optDouble("am", 0.0), o.optString("tx")))
            }
        } catch (e: Exception) { }
        return out
    }

    private fun write(ctx: Context, list: List<Entry>) {
        val arr = JSONArray()
        // গোপনীয়তা: পাঠানো হয়ে যাওয়া SMS ৭ দিন পর ফোন থেকে অটো-মুছে যায়
        val cutoff = System.currentTimeMillis() - 7L * 24 * 3600 * 1000
        list.filter { !(it.status == "sent" && it.ts < cutoff) }.takeLast(MAX).forEach {
            arr.put(JSONObject().put("id", it.id).put("s", it.sender).put("b", it.body).put("t", it.ts)
                .put("st", it.status).put("n", it.note).put("tr", it.tries).put("sm", it.sim)
                .put("am", it.amt).put("tx", it.trx))
        }
        prefs(ctx).edit().putString("log", arr.toString()).apply()
    }

    /** একই প্রেরক + একই লেখা ১০ মিনিটের মধ্যে আবার এলে ডুপ্লিকেট ধরা হয় */
    @Synchronized fun isDuplicate(ctx: Context, sender: String, body: String): Boolean {
        val since = System.currentTimeMillis() - 10 * 60 * 1000
        return entries(ctx).any { it.ts >= since && it.sender == sender && it.body == body }
    }

    @Synchronized fun add(ctx: Context, sender: String, body: String, sim: Int = 0): Long {
        val list = entries(ctx)
        val id = maxOf(System.currentTimeMillis(), (list.maxOfOrNull { it.id } ?: 0L) + 1)
        val info = Parser.parse(body)
        list.add(Entry(id, sender, body, System.currentTimeMillis(), "pending", "", 0, sim,
            if (info.incoming) info.amount else 0.0, info.trx))
        write(ctx, list)
        listener?.invoke()
        return id
    }

    @Synchronized fun find(ctx: Context, id: Long): Entry? = entries(ctx).firstOrNull { it.id == id }

    @Synchronized fun update(ctx: Context, id: Long, status: String, note: String, tries: Int) {
        val list = entries(ctx)
        list.firstOrNull { it.id == id }?.let { it.status = status; it.note = note; it.tries = tries }
        write(ctx, list)
        listener?.invoke()
    }

    @Synchronized fun markSent(ctx: Context, id: Long) {
        val e = find(ctx, id)
        if (e != null && e.status == "sent") return          // দুইবার গোনা হবে না
        update(ctx, id, "sent", "", 0)
        prefs(ctx).edit().putInt("sent_total", sentTotal(ctx) + 1).apply()
        if (e != null) addStat(ctx, e)
        FpWidget.refresh(ctx)
        listener?.invoke()
    }

    @Synchronized fun clear(ctx: Context) {
        prefs(ctx).edit().putString("log", "[]").apply()
        listener?.invoke()
    }

    // ------------------------------------------------------------------ আয়ের হিসাব (৪০ দিন)
    private fun dayKey(ts: Long): String = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date(ts))

    private fun loadStats(ctx: Context): JSONObject =
        try { JSONObject(prefs(ctx).getString("stats", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }

    @Synchronized private fun addStat(ctx: Context, e: Entry) {
        if (e.amt <= 0.0) return
        val root = loadStats(ctx)
        val dk = dayKey(e.ts)
        val day = root.optJSONObject(dk) ?: JSONObject()
        val prov = Parser.provider(e.sender)
        val cur = day.optJSONArray(prov)
        val c = (cur?.optInt(0) ?: 0) + 1
        val a = (cur?.optDouble(1) ?: 0.0) + e.amt
        day.put(prov, JSONArray().put(c).put(a))
        root.put(dk, day)
        val cutoff = dayKey(System.currentTimeMillis() - 40L * 86400000)
        val old = ArrayList<String>()
        val ki = root.keys()
        while (ki.hasNext()) { val k = ki.next(); if (k < cutoff) old.add(k) }
        old.forEach { root.remove(it) }
        prefs(ctx).edit().putString("stats", root.toString()).apply()
    }

    /** শেষ [days] দিনের (আজসহ) মোট */
    fun sumDays(ctx: Context, days: Int): Sum {
        val root = loadStats(ctx)
        var c = 0; var a = 0.0
        val now = System.currentTimeMillis()
        for (i in 0 until days) {
            val day = root.optJSONObject(dayKey(now - i * 86400000L)) ?: continue
            val ki = day.keys()
            while (ki.hasNext()) { val arr = day.optJSONArray(ki.next()) ?: continue; c += arr.optInt(0); a += arr.optDouble(1) }
        }
        return Sum(c, a)
    }

    fun byProvider(ctx: Context, days: Int): Map<String, Sum> {
        val root = loadStats(ctx)
        val cnt = LinkedHashMap<String, Int>(); val amt = LinkedHashMap<String, Double>()
        val now = System.currentTimeMillis()
        for (i in 0 until days) {
            val day = root.optJSONObject(dayKey(now - i * 86400000L)) ?: continue
            val ki = day.keys()
            while (ki.hasNext()) {
                val p = ki.next(); val arr = day.optJSONArray(p) ?: continue
                cnt[p] = (cnt[p] ?: 0) + arr.optInt(0); amt[p] = (amt[p] ?: 0.0) + arr.optDouble(1)
            }
        }
        val out = LinkedHashMap<String, Sum>()
        amt.entries.sortedByDescending { it.value }.forEach { out[it.key] = Sum(cnt[it.key] ?: 0, it.value) }
        return out
    }

    /** index 0 = সবচেয়ে পুরনো, শেষটি = আজ */
    fun perDay(ctx: Context, days: Int): DoubleArray {
        val root = loadStats(ctx)
        val out = DoubleArray(days)
        val now = System.currentTimeMillis()
        for (i in 0 until days) {
            val day = root.optJSONObject(dayKey(now - i * 86400000L)) ?: continue
            var a = 0.0
            val ki = day.keys()
            while (ki.hasNext()) { a += day.optJSONArray(ki.next())?.optDouble(1) ?: 0.0 }
            out[days - 1 - i] = a
        }
        return out
    }
}
