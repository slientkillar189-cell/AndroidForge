package com.freepay.sms

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.provider.Telephony
import java.util.concurrent.atomic.AtomicBoolean

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        if (!Store.enabled(ctx)) return
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(i) ?: return
        val sender = msgs.firstOrNull()?.originatingAddress ?: return
        val body = msgs.joinToString("") { it.messageBody ?: "" }
        val kws = Store.keywords(ctx).split(",").map { it.trim().lowercase() }.filter { it.isNotEmpty() }
        // শুধু পেমেন্ট সার্ভিসের SMS যায়; OTP/ব্যক্তিগত SMS কখনো সার্ভারে পাঠানো হয় না
        if (kws.none { sender.lowercase().contains(it) }) return
        val app = ctx.applicationContext
        if (Store.isDuplicate(app, sender, body)) return          // একই SMS দুইবার নয়
        val id = Store.add(app, sender, body, simSlot(i))
        val entry = Store.find(app, id)
        val voice = Store.speak(app) && entry != null && entry.amt > 0.0

        // সরাসরি পাঠানোর দ্রুত চেষ্টা; না হলে তবেই WorkManager (কম ওয়েকআপ = কম ব্যাটারি)
        val pr = goAsync()
        val done = AtomicBoolean(false)
        val finish = { if (done.compareAndSet(false, true)) { try { pr.finish() } catch (e: Exception) { } } }
        Handler(Looper.getMainLooper()).postDelayed({
            if (!done.get()) {
                val cur = Store.find(app, id)
                if (cur != null && cur.status != "sent") Uploader.enqueue(app, id)
                finish()
            }
        }, 9000)
        Thread {
            try { if (!Uploader.tryNow(app, id)) Uploader.enqueue(app, id) }
            catch (e: Exception) { Uploader.enqueue(app, id) }
            if (voice && entry != null) {
                try { Speaker.say(app, Speaker.bn(entry), Speaker.en(entry)) { finish() } } catch (e: Exception) { finish() }
            } else finish()
        }.start()
    }

    /** Dual SIM: কোন সিমে এসেছে (১ বা ২; জানা না গেলে ০). reflection + Throwable: পুরনো Android এ crash হয় না */
    private fun simSlot(i: Intent): Int {
        try {
            val sub = i.getIntExtra("subscription", -1)
            if (sub >= 0) {
                try {
                    val m = android.telephony.SubscriptionManager::class.java.getMethod("getSlotIndex", Int::class.javaPrimitiveType)
                    val s = (m.invoke(null, sub) as? Int) ?: -1
                    if (s >= 0) return s + 1
                } catch (t: Throwable) { }
            }
            for (k in arrayOf("slot", "slot_id", "simSlot", "phone", "android.telephony.extra.SLOT_INDEX")) {
                val v = i.getIntExtra(k, -1)
                if (v == 0 || v == 1) return v + 1
            }
        } catch (t: Throwable) { }
        return 0
    }
}
