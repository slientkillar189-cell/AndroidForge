package com.freepay.sms

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.*
import androidx.work.*
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = getSharedPreferences("cfg", MODE_PRIVATE)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }
        root.addView(TextView(this).apply { text = "FreePay SMS Gateway"; textSize = 22f })
        fun field(h: String, key: String, def: String) =
            EditText(this).apply { hint = h; setText(p.getString(key, def)); setSingleLine() }.also { root.addView(it) }
        val url = field("Server URL (https://yourdomain.com/freepay)", "url", "")
        val key = field("Device key (config.php → device_key)", "key", "")
        val kw = field("Sender keywords (comma separated)", "kw", "bkash,nagad,rocket,16216,upay,cellfin,tap,okwallet,ok wallet")
        status = TextView(this).apply { setPadding(0, pad, 0, pad) }
        root.addView(Button(this).apply {
            text = "Save & start"
            setOnClickListener {
                p.edit().putString("url", url.text.toString().trim()).putString("key", key.text.toString().trim())
                    .putString("kw", kw.text.toString()).apply()
                start(); refresh()
            }
        })
        root.addView(Button(this).apply {
            text = "Test connection"
            setOnClickListener {
                Thread {
                    val code = try { Api.post(applicationContext, "ping.php", JSONObject()) } catch (e: Exception) { -1 }
                    runOnUiThread { Toast.makeText(this@MainActivity, if (code == 200) "Connected ✓" else "Failed (HTTP $code) — URL/key দেখুন", Toast.LENGTH_LONG).show() }
                }.start()
            }
        })
        root.addView(status)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun granted() = checkSelfPermission(Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED

    private fun start() {
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("ping", ExistingPeriodicWorkPolicy.UPDATE,
            PeriodicWorkRequestBuilder<PingWorker>(15, TimeUnit.MINUTES)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build())
        if (granted()) askBattery() else requestPermissions(arrayOf(Manifest.permission.RECEIVE_SMS), 1)
    }

    private fun askBattery() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (!pm.isIgnoringBatteryOptimizations(packageName))
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(c, p, r); refresh()
        if (r.firstOrNull() == PackageManager.PERMISSION_GRANTED) askBattery()
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        val bat = (getSystemService(POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)
        status.text = "SMS permission: ${if (granted()) "OK" else "MISSING"}\nBattery unrestricted: ${if (bat) "OK" else "NO (SMS আসতে দেরি হতে পারে)"}"
    }
}
