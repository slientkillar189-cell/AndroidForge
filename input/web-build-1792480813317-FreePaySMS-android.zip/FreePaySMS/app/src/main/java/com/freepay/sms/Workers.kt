package com.freepay.sms

import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Api {
    fun post(ctx: Context, path: String, json: JSONObject): Int {
        val p = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)
        val base = (p.getString("url", "") ?: "").trim().trimEnd('/')
        if (base.isEmpty()) return -1
        val c = URL("$base/api/$path").openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"; c.connectTimeout = 15000; c.readTimeout = 15000; c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("X-Device-Key", (p.getString("key", "") ?: "").trim())
            c.outputStream.use { it.write(json.toString().toByteArray()) }
            return c.responseCode
        } finally { c.disconnect() }
    }
}

class UploadWorker(ctx: Context, p: WorkerParameters) : Worker(ctx, p) {
    override fun doWork(): Result = try {
        val j = JSONObject().put("sender", inputData.getString("s")).put("body", inputData.getString("b"))
        val code = Api.post(applicationContext, "sms.php", j)
        when {
            code == 200 -> Result.success()
            code in 400..499 -> Result.failure()          // ভুল key/URL: বারবার চেষ্টা করে লাভ নেই
            runAttemptCount > 20 -> Result.failure()
            else -> Result.retry()
        }
    } catch (e: Exception) { if (runAttemptCount > 20) Result.failure() else Result.retry() }
}

class PingWorker(ctx: Context, p: WorkerParameters) : Worker(ctx, p) {
    override fun doWork(): Result { try { Api.post(applicationContext, "ping.php", JSONObject()) } catch (e: Exception) { }; return Result.success() }
}
