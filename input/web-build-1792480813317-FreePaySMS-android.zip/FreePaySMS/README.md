# FreePay SMS (Android)
পেমেন্ট SMS সার্ভারে পাঠানোর অ্যাপ। শুধু কীওয়ার্ড মেলানো প্রেরকের (bKash, Nagad ইত্যাদি) SMS যায়।

## APK বানানো
1. Android Studio (Koala বা নতুন) ইনস্টল করুন → **Open** → `FreePaySMS` ফোল্ডার বেছে নিন → Gradle sync শেষ হতে দিন (ইন্টারনেট লাগবে)।
2. **Build → Build Bundle(s)/APK(s) → Build APK(s)** → `app/build/outputs/apk/debug/app-debug.apk` ফোনে ইনস্টল করুন।

## ফোনে সেটআপ
1. অ্যাপ খুলে Server URL (`https://yourdomain.com/freepay`), Device key দিন → **Save & start** → SMS অনুমতি ও Battery "Unrestricted" দিন → **Test connection** এ ✓ দেখুন।
2. Android 13+ এ APK বাইরে থেকে ইনস্টল করলে SMS অনুমতি ধূসর থাকতে পারে: Settings → Apps → FreePay SMS → ⋮ → **Allow restricted settings**, তারপর আবার অনুমতি দিন।
3. ফোনের সেটিংয়ে অ্যাপটির Auto-start/Background চালু রাখুন (Xiaomi, Oppo, Vivo, Samsung এ আলাদা ব্যাটারি সেটিং থাকে)।
4. পেমেন্ট নেওয়ার সিমটি এই ফোনে থাকতে হবে এবং ফোনে ইন্টারনেট চালু রাখতে হবে।
