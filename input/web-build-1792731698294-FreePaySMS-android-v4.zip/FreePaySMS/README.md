# FreePay SMS (Android) v4.0 — by CHAKRABORTY IT LTD
পেমেন্ট SMS সার্ভারে পাঠানোর অ্যাপ। শুধু কীওয়ার্ড মেলানো প্রেরকের (bKash, Nagad ইত্যাদি) SMS যায়।

## নতুন কী আছে (v4.0)
- 💰 **আয়ের ড্যাশবোর্ড**: আজ / ৭ দিন / ৩০ দিনের মোট, ৭ দিনের বার চার্ট, bKash/Nagad/Rocket আলাদা হিসাব (SMS থেকে অঙ্ক আনুমানিকভাবে পড়া হয়; শুধু সফলভাবে পাঠানো ইনকামিং SMS গোনা হয়)
- 🔊 **ভয়েস অ্যালার্ট**: "bKash থেকে ৫০০ টাকা পেয়েছেন" (বাংলা TTS না থাকলে English) — 🔊 Test voice বাটন আছে
- 🩺 **Health check + 🔧 Fix**: অনুমতি, Battery, ইন্টারনেট, সার্ভার, key এক ট্যাপে যাচাই
- 🧩 **হোম স্ক্রিন উইজেট** (আজকের আয়, ট্যাপে ON/OFF) ও **Quick Settings টাইল** (নিজে থেকে কখনো জাগে না)
- 🔒 **অ্যাপ লক** (ফোনের PIN/প্যাটার্ন/ফিঙ্গারপ্রিন্ট), ⚫ **AMOLED কালো থিম**
- 🌐 **Backup server**: প্রধান সার্ভার ব্যর্থ হলে ব্যাকআপে পাঠায়
- 🔎 লগে সার্চ, 💾 Backup / ♻️ Restore (ক্লিপবোর্ডে), 🌙 রাত ৯টায় দিনের সারাংশ নোটিফিকেশন

## আগের ভার্সন (v3.0) — ব্যাটারি সাশ্রয় + সুপার ফিচার
**ব্যাটারি**
- সব অ্যানিমেশন ৩০fps (shimmer ২০fps) সীমায়; ব্যাকগ্রাউন্ডে কোনো অ্যানিমেশন চলে না
- **Lite mode** সুইচ + Battery Saver চালু / ব্যাটারি <30% (চার্জে নেই) / সিস্টেমে animation বন্ধ থাকলে অটো Lite
- Ping প্রতি ১৫ মিনিটের বদলে ৬০ মিনিটে, শুধু ব্যাটারি কম না থাকলে
- **Instant send**: SMS আসার সাথে সাথে সরাসরি সার্ভারে পাঠানোর চেষ্টা; ব্যর্থ হলে তবেই WorkManager (কম ওয়েকআপ)
**ফিচার**
- ডুপ্লিকেট SMS ফিল্টার (১০ মিনিট), Dual-SIM শনাক্ত (SIM1/SIM2, সার্ভারে `sim` ফিল্ডে)
- পাঠাতে ব্যর্থ হলে নোটিফিকেশন (Android 13+ এ Notification অনুমতি দিন)
- Export log (CSV শেয়ার), পাঠানো SMS ৭ দিন পর ফোন থেকে অটো-মুছে যায়

## আগের ভার্সন (v2.0)
- নতুন ডার্ক প্রিমিয়াম UI + অ্যানিমেটেড ব্যাকগ্রাউন্ড, পালসিং লোগো, shimmer ব্র্যান্ড, count-up স্ট্যাটস
- **Test connection ঠিক করা হয়েছে**: এখন ফিল্ডে লেখা URL/key দিয়েই টেস্ট হয় (আগে শুধু Save করা মান ব্যবহার হতো), http→https redirect চলে, https না লিখলেও চলে, বিস্তারিত এরর কারণ দেখায়
- Connection status (live), Sent / Pending / Failed কাউন্টার, Activity log (ট্যাপ করলে পুরো SMS), Retry failed, Forwarding ON/OFF সুইচ
- Device key show/hide, error details Copy, Help guide, Battery/App settings শর্টকাট
- নতুন লোগো ও অ্যাপ আইকন (adaptive + themed), `branding/` ফোল্ডারে PNG লোগো ও ব্যানার

## APK বানানো
1. Android Studio (Koala বা নতুন) → **Open** → `FreePaySMS` ফোল্ডার → Gradle sync (ইন্টারনেট লাগবে)।
2. **Build → Build APK(s)** → `app/build/outputs/apk/debug/app-debug.apk`।
   অথবা GitHub এ আপলোড করলে `.github/workflows/build.yml` নিজেই APK বানাবে।

## ফোনে সেটআপ
1. Server URL (`https://yourdomain.com/freepay`), Device key দিন → **Save & start** → SMS অনুমতি ও Battery "Unrestricted" → **Test connection** এ ✅ দেখুন।
2. Android 13+ এ SMS অনুমতি ধূসর হলে: Settings → Apps → FreePay SMS → ⋮ → **Allow restricted settings**।
3. Xiaomi/Oppo/Vivo/Samsung এ Auto-start/Background চালু রাখুন।
4. পেমেন্টের সিমটি এই ফোনে থাকতে হবে, ইন্টারনেট চালু রাখতে হবে।

© CHAKRABORTY IT LTD
