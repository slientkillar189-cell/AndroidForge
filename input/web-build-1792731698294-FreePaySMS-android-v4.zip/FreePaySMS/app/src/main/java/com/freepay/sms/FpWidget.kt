package com.freepay.sms

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

/** হোম স্ক্রিন উইজেট: আজকের আয় + ON/OFF (ট্যাপ করলে ফরওয়ার্ডিং টগল)। updatePeriodMillis=0 → নিজে থেকে কখনো জাগে না। */
class FpWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        for (id in ids) mgr.updateAppWidget(id, build(ctx))
    }

    override fun onReceive(ctx: Context, i: Intent) {
        super.onReceive(ctx, i)
        if (i.action == ACTION_TOGGLE) Store.setEnabled(ctx, !Store.enabled(ctx))
    }

    companion object {
        const val ACTION_TOGGLE = "com.freepay.sms.TOGGLE"

        fun build(ctx: Context): RemoteViews {
            val rv = RemoteViews(ctx.packageName, R.layout.widget)
            val s = Store.sumDays(ctx, 1)
            val on = Store.enabled(ctx)
            rv.setTextViewText(R.id.wAmount, "৳" + Parser.fmt(s.amount))
            rv.setTextViewText(R.id.wSub, "আজ ${s.count}টি • " + if (on) "🟢 ON" else "🔴 OFF")
            val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            val toggle = PendingIntent.getBroadcast(ctx, 0, Intent(ctx, FpWidget::class.java).setAction(ACTION_TOGGLE), flags)
            val open = PendingIntent.getActivity(ctx, 1, Intent(ctx, MainActivity::class.java), flags)
            rv.setOnClickPendingIntent(R.id.wSub, toggle)
            rv.setOnClickPendingIntent(R.id.wAmount, open)
            rv.setOnClickPendingIntent(R.id.wTitle, open)
            return rv
        }

        fun refresh(ctx: Context) {
            try {
                val app = ctx.applicationContext
                val mgr = AppWidgetManager.getInstance(app)
                val ids = mgr.getAppWidgetIds(ComponentName(app, FpWidget::class.java))
                if (ids.isNotEmpty()) mgr.updateAppWidget(ids, build(app))
            } catch (e: Exception) { }
        }
    }
}
