# FreePay SMS (Android) v2.0 — by CHAKRABORTY IT LTD
পেমেন্ট SMS সার্ভারে পাঠানোর অ্যাপ। শুধু কীওয়ার্ড মেলানো প্রেরকের (bKash, Nagad ইত্যাদি) SMS যায়।

## নতুন কী আছে (v2.0)
- নতুন ডার্ক প্রিমিয়াম UI + অ্যানিমেটেড ব্যাকগ্রাউন্ড, পালসিং লোগো, shimmer ব্র্যান্ড, count-up স্ট্যাটস
- **Test connection ঠিক করা হয়েছে**: এখন ফিল্ডে লেখা URL/key দিয়েই টেস্ট হয় (আগে শুধু Save করা মান ব্যবহার হতো), http→https redirect চলে, https না লিখলেও চলে, বিস্তারিত এরর কারণ দেখায়
- Connection status (live), Sent / Pending / Failed কাউন্টার, Activity log (ট্যাপ করলে পুরো SMS), Retry failed, Forwarding ON/OFF সুইচ
- Device key show/hide, error details Copy, Help guide, Battery/App settings শর্টকাট
- নতুন লোগো ও অ্যাপ আইকন (adaptive + themed), `branding/` ফোল্ডারে PNG লোগো ও ব্যানার

## APK বানানো
1. Android Studio (Koala বা নতুন) → **Open** → `FreePaySMS` ফোল্ডার → Gradle sync (ইন্টারনেট লাগবে)।
2. **Build → Build APK(s)** → `app/build/outputs/apk/debug/app-debug.apk`।
   অথবা GitHub এ আপলোড করলে `.github/workflows/build.yml` নিজেই APK বানাবে।

## ফোনে সেটআপ
1. Server URL (`https://yourdomain.com/freepay`), Device key দিন → **Save & start** → SMS অনুমতি ও Battery "Unrestricted" → **Test connection** এ ✅ দেখুন।
2. Android 13+ এ SMS অনুমতি ধূসর হলে: Settings → Apps → FreePay SMS → ⋮ → **Allow restricted settings**।
3. Xiaomi/Oppo/Vivo/Samsung এ Auto-start/Background চালু রাখুন।
4. পেমেন্টের সিমটি এই ফোনে থাকতে হবে, ইন্টারনেট চালু রাখতে হবে।

© CHAKRABORTY IT LTD
