package com.freepay.sms

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import androidx.work.*
import java.util.concurrent.TimeUnit

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        if (!Store.enabled(ctx)) return
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(i) ?: return
        val sender = msgs.firstOrNull()?.originatingAddress ?: return
        val body = msgs.joinToString("") { it.messageBody ?: "" }
        val kws = Store.keywords(ctx).split(",").map { it.trim().lowercase() }.filter { it.isNotEmpty() }
        // শুধু পেমেন্ট সার্ভিসের SMS যায়; OTP/ব্যক্তিগত SMS কখনো সার্ভারে পাঠানো হয় না
        if (kws.none { sender.lowercase().contains(it) }) return
        val id = Store.add(ctx, sender, body)
        val req = OneTimeWorkRequestBuilder<UploadWorker>()
            .setInputData(workDataOf("id" to id))
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS).build()
        WorkManager.getInstance(ctx).enqueue(req)
    }
}
