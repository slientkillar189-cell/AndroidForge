package com.freepay.sms

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

object Store {
    const val DEFAULT_KW = "bkash,nagad,rocket,16216,upay,cellfin,tap,okwallet,ok wallet"
    private const val MAX = 100

    data class Entry(val id: Long, val sender: String, val body: String, val ts: Long,
                     var status: String, var note: String, var tries: Int)

    @Volatile var listener: (() -> Unit)? = null

    fun prefs(ctx: Context): SharedPreferences = ctx.applicationContext.getSharedPreferences("cfg", Context.MODE_PRIVATE)
    fun url(ctx: Context): String = prefs(ctx).getString("url", "") ?: ""
    fun key(ctx: Context): String = prefs(ctx).getString("key", "") ?: ""
    fun keywords(ctx: Context): String = prefs(ctx).getString("kw", DEFAULT_KW) ?: DEFAULT_KW
    fun enabled(ctx: Context): Boolean = prefs(ctx).getBoolean("enabled", true)
    fun setEnabled(ctx: Context, on: Boolean) { prefs(ctx).edit().putBoolean("enabled", on).apply() }
    fun saveConfig(ctx: Context, url: String, key: String, kw: String) {
        prefs(ctx).edit().putString("url", url).putString("key", key).putString("kw", kw).apply()
    }

    fun sentTotal(ctx: Context): Int = prefs(ctx).getInt("sent_total", 0)
    fun connState(ctx: Context): Int = prefs(ctx).getInt("conn", 0)       // 0 unknown, 1 ok, 2 failed
    fun connTs(ctx: Context): Long = prefs(ctx).getLong("conn_ts", 0L)

    fun setConn(ctx: Context, ok: Boolean, msg: String) {
        prefs(ctx).edit().putInt("conn", if (ok) 1 else 2).putLong("conn_ts", System.currentTimeMillis())
            .putString("conn_msg", msg).apply()
        listener?.invoke()
    }

    @Synchronized fun entries(ctx: Context): MutableList<Entry> {
        val out = ArrayList<Entry>()
        try {
            val arr = JSONArray(prefs(ctx).getString("log", "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Entry(o.getLong("id"), o.optString("s"), o.optString("b"), o.optLong("t"),
                    o.optString("st", "pending"), o.optString("n"), o.optInt("tr")))
            }
        } catch (e: Exception) { }
        return out
    }

    private fun write(ctx: Context, list: List<Entry>) {
        val arr = JSONArray()
        list.takeLast(MAX).forEach {
            arr.put(JSONObject().put("id", it.id).put("s", it.sender).put("b", it.body).put("t", it.ts)
                .put("st", it.status).put("n", it.note).put("tr", it.tries))
        }
        prefs(ctx).edit().putString("log", arr.toString()).apply()
    }

    @Synchronized fun add(ctx: Context, sender: String, body: String): Long {
        val list = entries(ctx)
        val id = maxOf(System.currentTimeMillis(), (list.maxOfOrNull { it.id } ?: 0L) + 1)
        list.add(Entry(id, sender, body, System.currentTimeMillis(), "pending", "", 0))
        write(ctx, list)
        listener?.invoke()
        return id
    }

    @Synchronized fun find(ctx: Context, id: Long): Entry? = entries(ctx).firstOrNull { it.id == id }

    @Synchronized fun update(ctx: Context, id: Long, status: String, note: String, tries: Int) {
        val list = entries(ctx)
        list.firstOrNull { it.id == id }?.let { it.status = status; it.note = note; it.tries = tries }
        write(ctx, list)
        listener?.invoke()
    }

    @Synchronized fun markSent(ctx: Context, id: Long) {
        update(ctx, id, "sent", "", 0)
        prefs(ctx).edit().putInt("sent_total", sentTotal(ctx) + 1).apply()
        listener?.invoke()
    }

    @Synchronized fun clear(ctx: Context) {
        prefs(ctx).edit().putString("log", "[]").apply()
        listener?.invoke()
    }
}
