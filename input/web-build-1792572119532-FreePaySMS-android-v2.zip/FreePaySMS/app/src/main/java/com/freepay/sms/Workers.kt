package com.freepay.sms

import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters
import org.json.JSONObject

class UploadWorker(ctx: Context, p: WorkerParameters) : Worker(ctx, p) {
    override fun doWork(): Result {
        val c = applicationContext
        val id = inputData.getLong("id", 0L)
        val e = Store.find(c, id) ?: return Result.success()
        val j = JSONObject().put("sender", e.sender).put("body", e.body)
        val r = Api.post(Store.url(c), Store.key(c), "sms.php", j)
        val tries = runAttemptCount + 1
        return when {
            r.ok -> { Store.markSent(c, id); Store.setConn(c, true, "OK"); Result.success() }
            r.error == null && (r.html || (r.code in 400..499 && r.code != 429 && r.code != 408)) -> {
                Store.update(c, id, "failed", Api.short(r), tries)   // ভুল key/URL: বারবার চেষ্টা করে লাভ নেই
                Store.setConn(c, false, Api.short(r))
                Result.failure()
            }
            tries > 20 -> { Store.update(c, id, "failed", Api.short(r), tries); Result.failure() }
            else -> { Store.update(c, id, "pending", Api.short(r), tries); Result.retry() }
        }
    }
}

class PingWorker(ctx: Context, p: WorkerParameters) : Worker(ctx, p) {
    override fun doWork(): Result {
        val c = applicationContext
        if (Store.url(c).isNotEmpty()) {
            val r = Api.post(Store.url(c), Store.key(c), "ping.php", JSONObject())
            Store.setConn(c, r.ok, Api.verdict(r).msg)
        }
        return Result.success()
    }
}
